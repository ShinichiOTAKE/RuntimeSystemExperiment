package jp.experiment.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import jp.experiment.security.JwtGenerationFilter;
import jp.experiment.security.JwtVerificationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
	
	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
		
		httpSecurity.httpBasic().disable();
		httpSecurity.csrf().disable();
		httpSecurity.cors().configurationSource(corsConfigurationSource());
		httpSecurity.authorizeHttpRequests(authorize -> authorize
			.requestMatchers("/actuator/health").permitAll()
			.requestMatchers("/v1/authenticate").permitAll()
			.anyRequest().authenticated()
		);
		httpSecurity.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		
		var manager = authenticationManager(httpSecurity.getSharedObject(AuthenticationConfiguration.class));
		httpSecurity.addFilter(new JwtGenerationFilter(manager));
		httpSecurity.addFilterAfter(new JwtVerificationFilter(), JwtGenerationFilter.class);
		
		return httpSecurity.build();
	}
	
    @Bean
    AuthenticationManager authenticationManager(
    		AuthenticationConfiguration authenticationConfiguration)
    			throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }
	
	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder(12);
	}
	
	private CorsConfigurationSource corsConfigurationSource() {
    	var corsConfiguration = new CorsConfiguration();
	    corsConfiguration.addAllowedMethod("POST");
	    corsConfiguration.addAllowedHeader(CorsConfiguration.ALL);
	    corsConfiguration.addExposedHeader("X-AUTH-TOKEN");
	    corsConfiguration.addAllowedOrigin("http://localhost:5173");
	    corsConfiguration.setAllowCredentials(true);

	    var corsSource = new UrlBasedCorsConfigurationSource();
	    corsSource.registerCorsConfiguration("/**", corsConfiguration);
	
	    return corsSource;
    }
}