package jp.experiment.constant;

public class Jwt {
	
	public static final long EXPIRATION_SECONDS = 8 * 60 * 60;
	
	public static final String ISSUER = "OkayaJwtProvider";

}
