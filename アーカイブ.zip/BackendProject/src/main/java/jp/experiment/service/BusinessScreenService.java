package jp.experiment.service;

public interface BusinessScreenService {

}