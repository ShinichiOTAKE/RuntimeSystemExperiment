package jp.experiment.security;

import lombok.Data;

@Data
public class UserModel {
	private String username;
	private String password;
}
