package jp.experiment.security;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetail implements UserDetailsService {
	
	private final Map<String, String> users = new HashMap<>();
	
	public UserDetail() {
		users.put("test-01" , "$2a$12$1AgG0/ITif6wI8J4BTDNruyJ10g7ZdXhLDIQyFwgxljlIDGzxRqNG");
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		String password = users.get(username);
		if (password == null) {
			throw new UsernameNotFoundException("User not found:" + username);
		}

		return User.withUsername(username)
				.password(password)
				.roles("USER")
				.build();
	}
}