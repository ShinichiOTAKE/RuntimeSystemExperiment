package jp.experiment.security;

import java.io.IOException;
import java.util.ArrayList;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.auth0.jwt.interfaces.DecodedJWT;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jp.experiment.util.JwtUtil;

public class JwtVerificationFilter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(
			HttpServletRequest request,
			HttpServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		
		String header = request.getHeader("Authorization");
		if (header != null && StringUtils.startsWithIgnoreCase(header, "Bearer ")) {
			var bearerToken = header.substring(7);
				
			var jwtUtil = new JwtUtil();
			DecodedJWT decodedJwt = jwtUtil.verifyToken(bearerToken);
			SecurityContextHolder
				.getContext()
				.setAuthentication(
					new UsernamePasswordAuthenticationToken(
						decodedJwt.getSubject(),
						null,
						new ArrayList<>()
					)
				);
		}
		
		filterChain.doFilter(request, response);
	}
}
