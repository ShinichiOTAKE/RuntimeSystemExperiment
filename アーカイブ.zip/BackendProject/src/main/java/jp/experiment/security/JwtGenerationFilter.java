package jp.experiment.security;

import java.io.IOException;
import java.util.ArrayList;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jp.experiment.util.JwtUtil;

public class JwtGenerationFilter extends UsernamePasswordAuthenticationFilter {
	
	private final AuthenticationManager authenticationManager;
	
	public JwtGenerationFilter(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
		
		this.setRequiresAuthenticationRequestMatcher(
			new AntPathRequestMatcher("/v1/authenticate", "POST"));
		this.setUsernameParameter(SPRING_SECURITY_FORM_USERNAME_KEY);
		this.setPasswordParameter(SPRING_SECURITY_FORM_PASSWORD_KEY);
		
		this.setAuthenticationSuccessHandler((request, response, principal) -> {
			var jwtUtil = new JwtUtil();
			String token = jwtUtil.generateToken(principal.getName());
			response.setHeader("X-AUTH-TOKEN", token);
			response.setStatus(HttpServletResponse.SC_OK);
		});
		
		this.setAuthenticationFailureHandler((request, response, principal) -> {
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		});
	}
	
	@Override
	public Authentication attemptAuthentication(
			HttpServletRequest request, HttpServletResponse response) 
				throws AuthenticationException {
		try {
			UserModel principal = getUserModel(request);
			return this.authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(
						principal.getUsername(),
						principal.getPassword(),
						new ArrayList<>())
			);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	private UserModel getUserModel(HttpServletRequest request) throws StreamReadException, DatabindException, IOException {
		return new ObjectMapper().readValue(request.getInputStream(), UserModel.class);
	}
}