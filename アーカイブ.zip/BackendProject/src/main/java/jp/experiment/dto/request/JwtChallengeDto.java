package jp.experiment.dto.request;

import lombok.Data;

@Data
public class JwtChallengeDto {
	private String username;
	private String password;
}
