package jp.experiment.dto.request.impl;

import jp.experiment.dto.request.RequestDto;
import lombok.Data;

@Data
public class Prt0000010RequestDto implements RequestDto {

	private String bscd;

}