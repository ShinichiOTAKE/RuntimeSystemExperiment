package jp.experiment.dto.request;

public interface RequestDto {

}