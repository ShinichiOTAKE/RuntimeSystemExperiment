package jp.experiment.dto.response;

public interface TransformableJson {

}
