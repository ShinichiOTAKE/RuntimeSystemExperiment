package jp.experiment.util;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;

import jp.experiment.constant.Jwt;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class JwtUtil {
	
	//TODO プロダクション環境では環境変数化する。
	private static final String secretKey = "Okaya-SecretKey";
	
	public String generateToken(String subject) {
		var dateTimeNow = OffsetDateTime.now();
		Algorithm alogorithm = Algorithm.HMAC256(secretKey);
		return JWT.create()
				.withIssuer(Jwt.ISSUER)
				.withSubject(subject)
				.withExpiresAt(dateTimeNow.plusSeconds(Jwt.EXPIRATION_SECONDS).toInstant())
				.withIssuedAt(dateTimeNow.toInstant())
				.withJWTId(UUID.randomUUID().toString())
				.sign(alogorithm);
	}
	
	public DecodedJWT verifyToken(String token) {
		Algorithm algorithm = Algorithm.HMAC256(secretKey);
		JWTVerifier verifier =
			JWT
			.require(algorithm)
			.withIssuer(Jwt.ISSUER)
			.acceptExpiresAt(Jwt.EXPIRATION_SECONDS)
			.build();
		try {
			return verifier.verify(token);
		} catch (JWTVerificationException e) {
			throw e;
		}
	}
}
