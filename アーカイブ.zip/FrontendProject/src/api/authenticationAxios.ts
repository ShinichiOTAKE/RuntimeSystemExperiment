import axios from "axios";

import * as constant from "@/constant";

export default axios.create({ baseURL: constant.base.authentication });

export const authenticationAxios = axios.create({
    baseURL: constant.base.authentication,
    headers: { "Content-Type": "application/json" },
    withCredentials: true
});