import * as constant from "@/constant";
import axios, { AxiosResponse, AxiosError } from "axios";

//GET
export const interpretPostWithGet = <Req, Res>(
  uri: string,
  requestBodyData: Req,
  responseCallback: React.Dispatch<React.SetStateAction<Res>>,
): void => {
  axios.post(
    uri,
    requestBodyData,
    constant.httpGetConfigure
  )
  .then((response: AxiosResponse) => {
    responseCallback(response.data)
  })
  .catch(
    (e: AxiosError) => { throw new Error(e.message) }
  );
};

//POST
export const post = <Req, Res>(
  uri: string,
  requestBodyData: Req,
  responseCallback: React.Dispatch<React.SetStateAction<Res>>,
): void => {
  axios.post(
    uri,
    requestBodyData,
    constant.httpPostConfigure
  )
  .then((response: AxiosResponse) => {
    responseCallback(response.data)
  })
  .catch(
    (e: AxiosError) => { throw new Error(e.message) }
  )
};

//PUT
export const interpretPostWithPut = <Req, Res>(
  uri: string,
  requestBodyData: Req,
  responseCallback: React.Dispatch<React.SetStateAction<Res>>,
): void => {
  axios.post(
    uri,
    requestBodyData,
    constant.httpPutConfigure
  )
  .then((response: AxiosResponse) => {
    responseCallback(response.data)
  })
  .catch(
    (e: AxiosError) => { throw new Error(e.message) }
  );
};

//PATCH
export const interpretPostWithPatch = <Req, Res>(
  uri: string,
  requestBodyData: Req,
  responseCallback: React.Dispatch<React.SetStateAction<Res>>,
): void => {
  axios.post(
    uri,
    requestBodyData,
    constant.httpPatchConfigure
  )
  .then((response: AxiosResponse) => {
    responseCallback(response.data)
  })
  .catch(
    (e: AxiosError) => { throw new Error(e.message) }
  );
};

//DELETE
export const interpretPostWithDelete = <Req, Res>(
  uri: string,
  requestBodyData: Req,
  responseCallback: React.Dispatch<React.SetStateAction<Res>>,
): void => {
  axios.post(
    uri,
    requestBodyData,
    constant.httpDeleteConfigure
  )
  .then((response: AxiosResponse) => {
    responseCallback(response.data)
  })
  .catch(
    (e: AxiosError) => { throw new Error(e.message) }
  );
};