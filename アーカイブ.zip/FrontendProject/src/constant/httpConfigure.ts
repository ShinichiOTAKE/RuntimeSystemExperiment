import { AxiosRequestConfig } from "axios";

//GET
export const httpGetConfigure: AxiosRequestConfig = {
    headers: {
      "Content-Type": "application/json",
      "X-HTTP-Method-Override": "GET"
    }
};

//POST
export const httpPostConfigure: AxiosRequestConfig = {
  headers: {
    "Content-Type": "application/json",
  }
};

//PUT
export const httpPutConfigure: AxiosRequestConfig = {
  headers: {
    "Content-Type": "application/json",
    "X-HTTP-Method-Override": "PUT"
  }
};

//PATCH
export const httpPatchConfigure: AxiosRequestConfig = {
  headers: {
    "Content-Type": "application/json",
    "X-HTTP-Method-Override": "PATCH"
  }
};

//DELETE
export const httpDeleteConfigure: AxiosRequestConfig = {
  headers: {
    "Content-Type": "application/json",
    "X-HTTP-Method-Override": "DELETE"
  }
};