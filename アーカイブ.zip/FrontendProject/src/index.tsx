import React, { Suspense, StrictMode } from "react";
import { createRoot } from "react-dom/client";
import {
  createBrowserRouter,
  RouterProvider,
  useParams,
  Outlet,
} from "react-router-dom";

//import { AuthenticationProvider } from "./provider/AuthenticationProvider";
//import { AuthenticationUserProvider } from "./provider/AuthenticationProvider";
//import { ModalDialogProvider } from "./provider/ModalDialogProvider";
import { Provider } from "@/component/Provider"; 
import { lazyLoader } from "@/common/lazyLoader";

import Login from "@/feature/login";
import { BaseScreenLayout } from "./layout/BaseScreen";
import { NotFound } from "./layout/NotFound";
import { Spinner } from "@/component/Spinner";

import "@/style/style.css";
import { RouteGuardByAuthentication } from "./component/RouteGuardByAuthentication";

const BusinessScreen = () => {
  const { featureId } = useParams();
  const Component = lazyLoader(() => import(`./feature/${featureId}/index.tsx`));

  return (
    <Suspense fallback={Spinner}>
      <Component />
    </Suspense>
  );
};

const router = createBrowserRouter([
  {
    path: "/",
    element: <Outlet />,
    errorElement: <NotFound />,
    children: [
      {
        path: "/login",
        element: <Login />,
      },
    ],
  },
  {
    path: "/features",
    element:
      <RouteGuardByAuthentication
        component={<BaseScreenLayout />} 
        redirect="/login"
      />,
    errorElement: <NotFound />,
    children: [
      {
        path: "/:featureId",
        element: <BusinessScreen />
      },
    ],
  },
]);

//const router = createBrowserRouter([
//  {
//    path: "/",
//    element: <BaseScreenLayout />,
//    errorElement: <NotFound />,
//    children: [
//      {
//        path: "/:featureId",
//        element: <BusinessScreen />,
//      }
//    ],
//  },
//]);

const container = document.getElementById("root");
if (!container) throw new Error("Can't find root element!!");

const root = createRoot(container);
root.render(
  <StrictMode>
    <Provider>
      <RouterProvider router={router}/>
    </Provider>
  </StrictMode>
);