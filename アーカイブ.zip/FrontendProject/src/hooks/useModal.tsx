import { useEffect, useState } from "react";

export const useModal = (id: string) => {
  const [modalContainer, setModalContainer] = useState<HTMLElement | null>(null);
  
  useEffect(() => {
    const targetContainer = document.querySelector<HTMLElement>(`#${id}`) ?? createModalContainer(id);
    document.body.appendChild(targetContainer);
    setModalContainer(targetContainer);
  }, []);

  return modalContainer;
};

const createModalContainer = (id: string): HTMLElement => {
  const newElement = document.createElement("div");
  newElement.setAttribute("id", id);

  return newElement;
};