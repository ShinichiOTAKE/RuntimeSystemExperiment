import axios from "@/api/authenticationAxios";
import { useContext } from "react";
import { AuthenticationContext } from "@/provider/AuthenticationProvider";

export const useRefreshToken = () => {
  const { setAuthentication } = useContext(AuthenticationContext);
  
  const refresh = async () => {
    const response =
      await axios.get(
        "/refresh", {
          withCredentials: true,
        }
      );
    setAuthentication((props: any) => {
      return {
        ...props,
        accessToken: response.data.accessToken
      };
    });

    return response.data.accessToken;
  };
  
  return refresh;
};