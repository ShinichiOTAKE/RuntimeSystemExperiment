import { useContext, useEffect } from "react";

import { authenticationAxios } from "@/api/authenticationAxios";
import { useRefreshToken } from "./useRefreshToken";
import { AuthenticateUserContextType, AuthenticationContext } from "@/provider/AuthenticationProvider";

export const useAuthenticateUserContext =
  ():AuthenticateUserContextType => {
    return useContext<AuthenticateUserContextType>(AuthenticationContext);
  }

//export const useAuthorizationAxios = () => {
//  const refresh = useRefreshToken();
//  const { authentication } = useContext(AuthenticationContext);

//  useEffect(() => {
//    const requestIntercept =
//      authenticationAxios
//        .interceptors
//        .request
//        .use(
//          (config) => {
//            if (!config.headers["Authorization"]) {
//              config.headers["Authorization"] = `Bearer ${authentication?.accessToken}`;
//            };
//            return config;
//          },
//          (error) => Promise.reject(error)
//        )
//    const responseIntercept =
//      authenticationAxios
//        .interceptors
//        .response
//        .use(
//          (response) => response,
//          async (error) => {
//            const previousRequest = error?.config;
//            if (error?.response.status === 403 &&
//                !previousRequest.sent) {
//              previousRequest.sent = true;
//              const newAccessToken = await refresh();
//              previousRequest
//                .headeras["Authorization"] = `Bearer ${newAccessToken}`;
//              return authenticationAxios(previousRequest);
//            };
//            return Promise.reject(error);
//          }
//        );
//
//      return () => {
//        authenticationAxios
//          .interceptors.request
//          .eject(requestIntercept);
//        authenticationAxios
//          .interceptors.response
//          .eject(responseIntercept);
//      }
//    }, [authentication, refresh]);
//
//    return authenticationAxios;
//};