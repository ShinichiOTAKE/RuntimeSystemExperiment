import React, { ReactNode, createContext, useState } from "react";

type Props = {
  children: ReactNode;
};

//type ContextType = {
//  authentication: any,
//  setAuthentication: React.Dispatch<React.SetStateAction<any>>,
//};
export type UserType = {
  name: string,
};

export type AuthenticateUserContextType = {
  user: UserType | null,
  signin: (user: UserType, callback:() => void) => void,
  signout: (callback:() => void) => void;
};

export const AuthenticationContext =
  createContext<AuthenticateUserContextType>({} as AuthenticateUserContextType);

export const AuthenticationUserProvider = (props: Props) => {
  const [user, setUser] = useState<UserType | null>(null);

  const signin = (newUser: UserType, callback: () => void) => {
    setUser(newUser);
    callback();
  };

  const signout = (callback: () => void) => {
    setUser(null);
    callback();
  };

  const value: AuthenticateUserContextType = { user, signin, signout };

  return (
    <AuthenticationContext.Provider value={value}>
      {props.children}
    </AuthenticationContext.Provider>
  );
};
//export const AuthenticationProvider: React.FC<Props> = ({children}) => {
//  const [authentication, setAuthentication] = useState({});
//
//  return (
//    <AuthenticationContext.Provider value={{ authentication, setAuthentication }}>
//      {children}
//    </AuthenticationContext.Provider>
//  );
//};