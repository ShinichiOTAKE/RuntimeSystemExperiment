import React, { ReactNode, createContext, FC, useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { useModal } from "@/hooks/useModal";

type Props = {
  children: ReactNode;
};

type ContextType = {
  open: (modal: ReactNode) => void;
  close: () => void;
};

export const ModalDialogContext = createContext<ContextType>({} as ContextType);

export const ModalDialogProvider: FC<Props> = ({ children }) => {
  const [ dialogNode, setDialogNode ] = useState<ReactNode>();
  const [ isVisible, setIsVisible ] = useState(false);

  const modalDialog = useModal("modalDialog");

  const open = (modal: ReactNode) => {
    setDialogNode(modal);
  };

  const close = () => {
    setDialogNode(null);
  };

  useEffect(() => {
    setIsVisible(true);
  }, []);

  if (!isVisible || !modalDialog) {
    return null;
  };

  return (
    <ModalDialogContext.Provider value={{open, close}}>
      {children}
      {createPortal(dialogNode, modalDialog)}
    </ModalDialogContext.Provider>
  );
};