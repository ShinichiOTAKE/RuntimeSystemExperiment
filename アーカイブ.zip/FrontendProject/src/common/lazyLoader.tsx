import React, { ComponentType, lazy } from "react";
import ErrorBoundary from "@/layout/ErrorBoundary";

const SHOULD_FORCE_RELOAD_KEY_NAME = "lazyLoad-force-reload";

export const lazyLoader =
  (factory: () => Promise<{default: ComponentType<any>}>) =>
    lazy(async() => {
      try {
        const component = await factory();
        window.sessionStorage.removeItem(SHOULD_FORCE_RELOAD_KEY_NAME);
        return component;

      } catch (e) {
        if (!window.sessionStorage.getItem(SHOULD_FORCE_RELOAD_KEY_NAME)) {
          window.sessionStorage.setItem(SHOULD_FORCE_RELOAD_KEY_NAME, "should-be");
          window.location.reload();
          return { default: () => <></> };
        };

        console.log(e);
        return {
          default: () => <ErrorBoundary errorDescription={e} />
        };
      };
    }
  );

export default lazyLoader;