import React, { useState, useEffect, useContext } from "react";
import { useReactTable, getCoreRowModel ,getPaginationRowModel, getSortedRowModel, SortingState} from "@tanstack/react-table";
import SearchScreenBuilder from "@/skeleton/screen/SearchScreen";
import Dialog from "@/feature/prt0000010/dialog1/index";
import { NewRegist } from "@/feature/prt0000010/dialog2/index";
import { ModalDialogContext } from "@/provider/ModalDialogProvider";
import * as constant from "@/constant";
import { OkyButton, OkyTextbox } from "@/component";
import * as restFacade from "@/api/restFacade";
import { TableBuilder } from "@/common/TableUtility";
import * as def from "./definition";

const screenId: string = "prt0000010";

const Screen = () => {

  const [keiyakuhEntities, setKeiyakuhEntities] =
    useState<def.listKeiyakuhResponse[]>([]);

  //各検索項目のuseState定義
  const [sch_bscd, setSch_bscd] = useState("");
  const [sch_kyutno, setSch_kyutno] = useState("");
  const [sch_kykb, setSch_kykb] = useState("");
  const [sch_nokist, setSch_nokist] = useState("");
  const [sch_nokied, setSch_nokied] = useState("");
  const [sch_urkrcd, setSch_urkrcd] = useState("");
  const [sch_urkrnm, setSch_urkrnm] = useState("");
  const [sch_srkrcd, setSch_srkrcd] = useState("");
  const [sch_srkrnm, setSch_srkrnm] = useState("");

  //検索リクエストセット
  const requestParam = () => {
    const req: def.listKeiyakuhRequest = {
      bscd: sch_bscd,
      kyutno: "",
      trkflg: false,
      kykb: "",
      nokist: "",
      nokied: "",
      urkrcd: "",
      srkrcd: ""
    }
    return req
  };
  //テーブル作成
  const [sorting, setSorting] = React.useState<SortingState>([])
  const keiyakuhTable = useReactTable({
    data: keiyakuhEntities,
    columns: def.keiyakuhColumns,
    state: {
			sorting,
		},
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  //検索実行
  const search = () => {
    restFacade.interpretPostWithGet<def.listKeiyakuhRequest, def.listKeiyakuhResponse[]>(
      constant.accessTo.businessScreenApi(screenId, "base", "onLoad"),
      requestParam(),
      setKeiyakuhEntities)
  }

  const clear = () => {
  }

  const setValue = (refelm:string, ret:string) => {
    const hoge = ret.split(":");
    switch(refelm){
      case "1" :{
        setSch_urkrcd(hoge[0])
        setSch_urkrnm(hoge[1])
      }
      break;
      case "2" :{
        setSch_srkrcd(hoge[0])
        setSch_srkrnm(hoge[1])
      }
    }
  }

  const { open, close }= useContext(ModalDialogContext);

  const handleOpen = async (refelm:string) => {
    const ret = await new Promise<string>((resolve) => {
      open(<Dialog promise={resolve} refelm={refelm}/>);
    });
    if(ret.length>0){
      setValue(refelm,ret);
    }
    
    close();
  };

  const newRegistOpen = () => {
    open(<NewRegist onClose={close}/>);
  };


  //スケルトン格納
  const headLabelData = {
    screenTitle: "契約検索",
    screenDetail: "処理を行う契約を検索します。",
  };

  const ButtonAreaElement =
    <div>
      <OkyButton color="green" wsize="md" hsize="lg" disabled={false} onClick={newRegistOpen}>契約新規作成</OkyButton>
    </div>
    ;

  const SearchAreaElement =
    <>
      <h2>検索条件</h2>
      <div className="bg-white">
        <div className="">
          <div className="flex">
            <div>
              <label className="block" htmlFor="bscd">部署</label>
              <OkyTextbox id="bscd" wsize="ss" value={sch_bscd} onChange={(event) => setSch_bscd(event.target.value)} />
              <OkyTextbox id="bsnm" wsize="xl" />
            </div>
            <div>
              <label className="block" htmlFor="kyutno">受付No</label>
              <OkyTextbox id="kyutno" wsize="lg" value={sch_kyutno} onChange={(event) => setSch_kyutno(event.target.value)} />
            </div>
            <div>
              <label className="block" htmlFor="trkflg">表示</label>
              <input className="m-1" id="trkflg" type="checkbox" /><span>取消契約非表示</span>
            </div>
          </div>
          <div className="flex">
            <div>
              <label className="block">契約区分</label>
              <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
                <option value={""} >選択してください</option>
                <option value={"1"}>売買契約</option>
                <option value={"2"}>買契約</option>
                <option value={"3"}>売契約</option>
                <option value={"4"}>マスタ</option>
              </select>
            </div>
            <div>
              <label className="block" htmlFor="nokist">納期</label>
              <OkyTextbox id="nokist" wsize="sm" value={sch_nokist} onChange={(event) => setSch_nokist(event.target.value)} />～
              <OkyTextbox id="nokied" wsize="sm" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />
            </div>
            <div>
              <label className="block" htmlFor="urkrcd">売上先</label>
              <OkyTextbox id="urkrcd" wsize="sm" value={sch_urkrcd} onChange={(event) => setSch_urkrcd(event.target.value)} />
              <OkyTextbox wsize="xl" value={sch_urkrnm} onChange={(event) => setSch_urkrnm(event.target.value)} />
              <OkyButton color="gray" wsize="sm" hsize="sm" onClick={()=>handleOpen("1")}>選択</OkyButton>
            </div>
            <div>
              <label className="block" htmlFor="srkrcd">仕入先</label>
              <OkyTextbox id="srkrcd" wsize="sm" value={sch_srkrcd} onChange={(event) => setSch_srkrcd(event.target.value)} />
              <OkyTextbox wsize="xl" value={sch_srkrnm} onChange={(event) => setSch_srkrnm(event.target.value)} />
              <OkyButton color="gray" wsize="sm" hsize="sm" onClick={()=>handleOpen("2")}>選択</OkyButton>
            </div>
          </div>
        </div>
        <div className="flex justify-end">
          <OkyButton color="gray" wsize="md" hsize="md" onClick={clear}>
            条件をクリア
          </OkyButton>
          <OkyButton color="green" wsize="md" hsize="md" onClick={search}>
            検索
          </OkyButton>
        </div>
      </div>
    </>
    ;

  const ResultTableElement =
    <TableBuilder
      table={keiyakuhTable}
      btnflg={true}
      onfunc={undefined}
    />
    ;
  return (
    <SearchScreenBuilder
      screenTitle={headLabelData.screenTitle}
      screenDetail={headLabelData.screenDetail}
      buttonArea={ButtonAreaElement}
      searchArea={SearchAreaElement}
      resultTable={ResultTableElement}
    />
  );
};

export default Screen;