export type Props = {
  promise: (value: string) => void,
  refelm: string,
  //message: string,
};

export const fmmtrkhpColumns = [
  {
    accessorKey: "trsekz",
    header: "名称"
  },
  {
    accessorKey: "trsemecn",
    header: "カナ"
  },
  {
    accessorKey: "trkrcd",
    header: "番号"
  },
  /*{
    accessorKey: "trrg",
    header: "略号"
  },*/
  {
    accessorKey: "trskbbkb",
    header: "タイプ"
  },
  {
    accessorKey: "ipsnkb",
    header: "社内売上先"
  }
];

export type listFmmtrkhpRequest = {
  schTrskbbkb: string //取引先区分
  schMtkb: string //検索方法
  schMachkb: string //マッチタイプ
  schWord: string //検索ワード
};

export type listFmmtrkhpResponse = {
  trsekz: string //名称
  trsemecn: string //カナ
  trkrcd: string //番号
  // trrg: string //略号
  trskbbkb: string //タイプ
  ipsnkb: string //社内売上先
};