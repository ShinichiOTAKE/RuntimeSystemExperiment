import React, { useState, useEffect, useContext } from "react";
import { useReactTable, getCoreRowModel, getPaginationRowModel, getSortedRowModel, SortingState } from "@tanstack/react-table";
import DialogSearchBuilder from "@/skeleton/dialog/SearchDialog";
import * as constant from "@/constant";
import { OkyButton, OkyTextbox } from "@/component";
import * as restFacade from "@/api/restFacade";
import { TableBuilder } from "@/common/TableUtility";
import * as def from "./definition";

const screenId: string = "prt0000010d1";
const Dialog = (props: def.Props) => {
  const {
    promise,
  } = props;

  //各検索項目のuseState定義
  const [fmmtrkhpEntities, setFmmtrkhpEntities] =
    useState<def.listFmmtrkhpResponse[]>([]);
  const [schTrskbbkb, setSchTrskbbkb] = useState("");
  const [schMtkb, setSchMtkb] = useState("");
  const [schMachkb, setSchMachkb] = useState("");
  const [schWord, setSchWord] = useState("");

  // ラジオボタンイベント発火時処理
  const schTrskbbkChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSchTrskbbkb(e.target.value);
  };
  const schMtkbChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSchMtkb(e.target.value);
  };
  const schMachkbChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSchMachkb(e.target.value);
  };

  //検索リクエストセット
  const requestParam = () => {
    const req: def.listFmmtrkhpRequest = {
      schTrskbbkb: schTrskbbkb,
      schMtkb: schMtkb,
      schMachkb: schMachkb,
      schWord: schWord,
    }
    return req
  };

  //テーブル作成
  const [sorting, setSorting] = React.useState<SortingState>([])
  const fmmtrkhpTable = useReactTable({
    data: fmmtrkhpEntities,
    columns: def.fmmtrkhpColumns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    state: {
      sorting,
    },
    onSortingChange: setSorting,
    getSortedRowModel: getSortedRowModel(),
  });

  //検索実行
  const search = () => {
    restFacade.interpretPostWithGet(
      constant.accessTo.businessScreenApi(screenId, "base", "onLoad"),
      requestParam(),
      setFmmtrkhpEntities)
  }
  const clear = () => {
  }

  //スケルトン格納
  const headLabelData = {
    screenTitle: "取引先検索",
    screenDetail: "取引先を検索します。該当の取引先を選択すると入力フォームに反映します。",
  };

  const SearchAreaElement =
    <>
      <h2>検索条件</h2>
      <div className="bg-white">
        <div>
          <div className="flex justify-between">
            <div onChange={schTrskbbkChange}>
              <label className="block" htmlFor="">取引先区分</label>
              <input type="radio" value="uri"></input>売上先<br />
              <input type="radio" value="ire"></input>仕入先
            </div>
            <div onChange={schMtkbChange}>
              <label className="block" htmlFor="">検索方法</label>
              <input type="radio" value="mei"></input>名称<br />
              <input type="radio" value="kn"></input>カナ<br />
              <input type="radio" value="bg"></input>番号<br />
              <input type="radio" value="rk"></input>略号
            </div>
            <div onChange={schMachkbChange}>
              <label className="block" htmlFor="">マッチタイプ</label>
              <input type="radio" value="mei"></input>検索ワードを含む<br />
              <input type="radio" value="kn"></input>検索ワードで始まる<br />
              <input type="radio" value="bg"></input>検索ワードで終わる<br />
              <input type="radio" value="rk"></input>検索ワードと一致する
            </div>
            <div>
              <label className="block" htmlFor="kyutno">検索ワード</label>
              <OkyTextbox id="word" wsize="xl" value={schWord} onChange={(event) => setSchWord(event.target.value)} />
            </div>
          </div>
        </div>
        <div className="flex justify-end">
          <OkyButton color="gray" wsize="md" hsize="md" onClick={clear}>
            条件をクリア
          </OkyButton>
          <OkyButton color="green" wsize="md" hsize="md" onClick={search}>
            検索
          </OkyButton>
        </div>
      </div>
    </>
    ;

  const ResultTableElement =
    <TableBuilder
      table={fmmtrkhpTable}
      btnflg={true}
      onfunc={promise}
    />
    ;

  return (
    <DialogSearchBuilder
      screenTitle={headLabelData.screenTitle}
      screenDetail={headLabelData.screenDetail}
      searchArea={SearchAreaElement}
      resultTable={ResultTableElement}
      onClose={() => promise("")}
    />
  );
};

export default Dialog;