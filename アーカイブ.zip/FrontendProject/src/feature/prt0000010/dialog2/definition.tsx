export type newContractRequest = {
  kykb: string //契約区分
  tpkb: string //タイプ
};