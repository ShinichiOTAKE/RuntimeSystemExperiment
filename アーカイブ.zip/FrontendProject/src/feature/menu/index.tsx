import React from "react";

const Screen = () => {

  return (
    <>
      <p className="text-3xl font-bold underline">This is a menu page.</p>
    </>
  );
};

export default Screen;