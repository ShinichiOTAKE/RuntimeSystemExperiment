import React from "react";
import { useNavigate, useLocation } from "react-router-dom";

import { UserType, AuthenticateUserContextType } from "@/provider/AuthenticationProvider";
import { useAuthenticateUserContext } from "@/hooks/useAuthorization";
import { OkyTextbox, OkyButton } from "@/component";

type CustomLocation = {
  state: {from: {pathName: string}},
};

const Login = () => {
  const navigate = useNavigate();
  const location: CustomLocation = useLocation() as CustomLocation;
  const fromPathName: string = location.state.from.pathName;
  const authenticateUser: AuthenticateUserContextType = useAuthenticateUserContext();

  const signin = () => {
    const user: UserType = {
      name: "岡谷　花子",
    }
    authenticateUser.signin(user, () => {
      navigate(fromPathName, { replace: true });
    });
  };

  return (
    <>
      <h1>ログイン</h1>
      <br/>
      <ul>
        <li>ユーザ名： <OkyTextbox id="username" wsize="xl" disabled /></li>
        <li>パスワード： <OkyTextbox id="password" wsize="xl" disabled /></li>
      </ul>
      <br/>
      <OkyButton color="gray" wsize="md" hsize="sm" onClick={() => signin()}>Sign up</OkyButton>
    </>
  );
};

export default Login;