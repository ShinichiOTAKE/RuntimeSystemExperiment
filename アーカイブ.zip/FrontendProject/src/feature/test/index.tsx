import React, { useContext } from "react";
import { ModalDialogContext } from "@/provider/ModalDialogProvider";
import Dialog from "./dialog1/index";

export const Screen = () => {
  const { open, close }= useContext(ModalDialogContext);

  const handleOpen = async () => {
    //open(<DialogSearchPatternBuilder onClose={close} />);
    //open(<Dialog onClose={close} title="Title" message="Message"/>);
    const ret = await new Promise<string>((resolve) => {
      open(<Dialog promise={resolve} title="Title" message="Message"/>);
    });
    console.log(ret);
    close();
  };

  return (
    <>
     <div>Test</div>
      <button onClick={ handleOpen }>開く</button>
    </>
  );
};

export default Screen;