export type Props = {
  promise: (value: string) => void,
  title: string,
  message: string,
};