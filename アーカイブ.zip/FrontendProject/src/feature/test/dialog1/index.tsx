import React from "react";
import { Props } from "./definition";
import { OkyButton } from "@/component";
import DialogSearchBuilder from "@/skeleton/dialog/SearchDialog";

const Dialog = (props: Props) => {
  const {
    promise,
    title,
    message,
  } = props;

  return (
    <DialogSearchBuilder
      screenTitle="だいあろぐたいとる"
      screenDetail="だいあろぐしょうさい"
      searchArea={<></>}
      resultTable={
        <div>
          <h1 className="text-3xl">Title: {title}</h1>
          <p>Message: {message}</p>
          <OkyButton color="gray" wsize="md" hsize="md" onClick={() => promise("OK")}>
            OK         
          </OkyButton>
          <OkyButton color="gray" wsize="md" hsize="md" onClick={() => promise("Cancel")}>
            Cancel        
          </OkyButton>
        </div>
      }
      onClose={() => promise("Cancel")}
    />
  );
};

export default Dialog;