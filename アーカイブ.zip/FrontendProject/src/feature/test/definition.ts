export type ModalInput = {
  initialSelectedValue: string;
};

export type ModalOutput = {
  selectedValue: string;
};