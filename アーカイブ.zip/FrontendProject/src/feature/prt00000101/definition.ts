export const keiyakubColumns = [
    {
      accessorKey: "KYUTNOGB",
      header: "No."
    },
    {
      accessorKey: "SYSKB",
      header: "システム区分"
    },
    {
      accessorKey: "HMSPKE",
      header: "品名寸法キー"
    },
    {
      accessorKey: "HMSPSE",
      header: "品名寸法正式"
    },
    {
      accessorKey: "SU",
      header: "数量"
    },
    {
      accessorKey: "SUTI",
      header: "数量単位"
    },
    {
      accessorKey: "JR",
      header: "重量"
    },
    {
      accessorKey: "JRTI",
      header: "重量単位"
    },
    {
      accessorKey: "URTNKG",
      header: "売上単価"
    }
  ];
  
  export type listKeiyakubRequest = {
    kyutno: string //受付No
  };
  
  export type listKeiyakubResponse = {
    btnstr: string,
    bsstr: string,
    kykb: string,
    urkrstr: string,
    srkrstr: string,
    kyutno: string,
    hatno: string
  };