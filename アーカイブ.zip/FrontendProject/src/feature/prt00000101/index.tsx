import React, { useState, useEffect, useContext } from "react";
import { useReactTable, getCoreRowModel, getPaginationRowModel, getSortedRowModel, SortingState } from "@tanstack/react-table";
import CreateScreenBuilder from "@/skeleton/screen/CreateScreen";
import Dialog from "@/feature/prt0000010/dialog1/index";
import { ModalDialogContext } from "@/provider/ModalDialogProvider";
import { OkyButton, OkyTextbox } from "@/component";
import { TableBuilder } from "@/common/TableUtility";
import * as def from "./definition";

const screenId: string = "prt00000101";
type scrProps = {
  saku: string;
  kb: string;
}

const Screen = (props:scrProps) => {

  const [keiyakubEntities, setKeiyakubEntities] =
    useState<def.listKeiyakubResponse[]>([]);

  //各検索項目のuseState定義
  const [sch_kykb, setSch_kykb] = useState("");
  const [sch_nokist, setSch_nokist] = useState("");
  const [sch_nokied, setSch_nokied] = useState("");

  //テーブル作成
  const keiyakuhTable = useReactTable({
    data: keiyakubEntities,
    columns: def.keiyakubColumns,
    state: {
    },
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
  });

  const kykb =
{switch(){

}

};
  const clear = () => {
  }

  const { open, close } = useContext(ModalDialogContext);

  const handleOpen = async (refelm:string) => {
    const ret = await new Promise<string>((resolve) => {
      open(<Dialog promise={resolve} refelm={refelm} />);
    });
    console.log(ret);
    close();
  };
  /*
  const newRegistOpen = () => {
    open(<NewRegist onClose={close} />);
  };
*/

  //スケルトン格納
  const headLabelData = {
    screenTitle: "契約新規作成",
    screenDetail: "新しい契約を作成します。",
  };

  const InputAreaElement =
    <>
      <div>
      <div>props.saku:{props.saku}<br/>props.kb:{props.kb}</div>
        <div className="w-full">
          <label className="" htmlFor="bscd">部署:</label><label className="" htmlFor="bscd">1431</label><label className="" htmlFor="bscd">鋼材第一部あいうえお</label><label className="" htmlFor="bscd">受付No.</label><label className="" htmlFor="bscd">0001893208</label>
        </div>
        <div className="bg-white border-gray-200 w-full flex">
          <div className="m-2 w-32">契約タイプ</div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">契約区分</label>
            <label className="" htmlFor="bscd">{}</label>
          </div>
        </div>
        <div className="bg-white border-gray-200 w-full flex">
          <div className="m-2 w-32">契約日・科目</div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">契約日</label>
            <OkyTextbox id="kyutno" wsize="lg" value={""} onChange={(event) => alert()} />
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">輸送方法</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""} ></option>
              <option value={"0"}>在庫</option>
              <option value={"1"}>直送</option>
              <option value={"2"}>買継</option>
            </select>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">売上勘定</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""} >関係無し</option>
              <option value={"1"}>一般売上</option>
              <option value={"2"}>輸出</option>
              <option value={"3"}>輸入品売上</option>
              <option value={"4"}>社内売上</option>
              <option value={"5"}></option>
              <option value={"6"}>外国間売上</option>
              <option value={"7"}>代行手数料</option>
              <option value={"8"}>代行売上</option>
            </select>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">仕入勘定</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""} >関係無し</option>
              <option value={"1"}>一般仕入</option>
              <option value={"2"}>輸入</option>
              <option value={"3"}></option>
              <option value={"4"}>社内仕入</option>
              <option value={"5"}></option>
              <option value={"6"}>外国間仕入</option>
              <option value={"7"}></option>
              <option value={"8"}>代行仕入</option>
            </select>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">紐店区分</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""} >関係無し</option>
              <option value={"1"}>紐付</option>
              <option value={"2"}>店売</option>
            </select>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">訂正区分</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""} >関係無し</option>
              <option value={"1"}>戻り戻し</option>
              <option value={"2"}>値引</option>
            </select>
          </div>
        </div>
        <div className="bg-white border-gray-200 w-full flex">
          <div className="m-2 w-32">区分</div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">商談／内示</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""}>正式</option>
              <option value={"1"}>商談</option>
              <option value={"2"}>内示</option>
              <option value={"3"}>先行</option>
            </select>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">商品区分</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""} ></option>
              <option value={"1"}>岡谷在庫</option>
              <option value={"2"}>メーカー</option>
              <option value={"3"}>預り在庫</option>
            </select>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">工事区分</label>
            <input className="m-1" id="trkflg" type="checkbox" />
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">品種区分</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""} ></option>
              <option value={"0"}>一般</option>
              <option value={"1"}>材料</option>
              <option value={"2"}>成品</option>
              <option value={"3"}>残材</option>
              <option value={"4"}>条鋼</option>
            </select>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">仲継地</label>
            <input className="m-1" id="trkflg" type="checkbox" />
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">注文書</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""} >作成しない</option>
              <option value={"1"}>注文書のみ</option>
              <option value={"2"}>注文書＋注文請書</option>
              <option value={"4"}>下請法用</option>
            </select>
          </div>
        </div>
        <div className="bg-white border-gray-200 w-full flex">
          <div className="m-2 w-32">取引先</div>
          <div className="m-2">
            <label className="block" htmlFor="nokist">売上先</label>
            <OkyTextbox id="nokist" wsize="xs" value={sch_nokist} onChange={(event) => setSch_nokist(event.target.value)} />-
            <OkyTextbox id="nokied" wsize="ss" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />-
            <OkyTextbox id="nokied" wsize="xs" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />
            <OkyButton color="gray" wsize="sm" hsize="sm" onClick={handleOpen}>選択</OkyButton>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="nokist">仕入先</label>
            <OkyTextbox id="nokist" wsize="xs" value={sch_nokist} onChange={(event) => setSch_nokist(event.target.value)} />-
            <OkyTextbox id="nokied" wsize="ss" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />-
            <OkyTextbox id="nokied" wsize="xs" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />
            <OkyButton color="gray" wsize="sm" hsize="sm" onClick={handleOpen}>選択</OkyButton>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="nokist">送り先</label>
            <OkyTextbox id="nokist" wsize="xs" value={sch_nokist} onChange={(event) => setSch_nokist(event.target.value)} />-
            <OkyTextbox id="nokied" wsize="ss" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />-
            <OkyTextbox id="nokied" wsize="xs" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />
            <OkyButton color="gray" wsize="sm" hsize="sm" onClick={handleOpen}>選択</OkyButton>
          </div>
        </div>
        <div className="bg-white border-gray-200 w-full flex">
          <div className="m-2 w-32">その他</div>
          <div className="m-2">
            <label className="block" htmlFor="nokist">保管場所</label>
            <OkyTextbox id="nokist" wsize="sm" value={sch_nokist} onChange={(event) => setSch_nokist(event.target.value)} />
            <OkyTextbox id="nokied" wsize="md" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />
          </div>
          <div className="m-2">
            <label className="block" htmlFor="bscd">受渡条件</label>
            <select className="m-1 border-2 border-gray-400 rounded" value={sch_kykb} onChange={(event) => setSch_kykb(event.target.value)}>
              <option value={""} ></option>
              <option value={"01"} >特別受渡条件</option>
              <option value={"10"} >オーダー渡し</option>
              <option value={"11"} >置場渡し</option>
              <option value={"12"} >置場積込渡し</option>
              <option value={"13"} >Ｆ．Ｏ．Ｂ</option>
              <option value={"20"} >岩壁着船乗渡し</option>
              <option value={"21"} >検収渡し</option>
              <option value={"28"} >船積込渡し</option>
              <option value={"30"} >据付渡し</option>
              <option value={"31"} >据付調整渡し</option>
              <option value={"32"} >竣工渡し</option>
              <option value={"33"} >Ｃ．Ｉ．Ｆ</option>
              <option value={"35"} >トラック持込渡し</option>
              <option value={"38"} >船乗り渡し</option>
              <option value={"39"} >乗り渡し</option>
              <option value={"40"} >トラック乗渡し</option>
              <option value={"41"} >トラック持込渡し</option>
              <option value={"48"} >岸壁渡し（船卸渡）</option>
              <option value={"50"} >配達</option>
              <option value={"51"} >浜出し</option>
              <option value={"52"} >持込渡し</option>
              <option value={"60"} >メーカー倉庫渡し</option>
              <option value={"61"} >メーカー指定倉庫渡し</option>
              <option value={"62"} >最寄駅側線入渡し</option>
              <option value={"63"} >最寄駅Ｏ／Ｒ</option>
              <option value={"70"} >引取</option>
              <option value={"71"} >元払</option>
              <option value={"72"} >メーカー持込渡し</option>
              <option value={"90"} >調整完了渡し</option>
              <option value={"91"} >要求仕様を満たすこと</option>
              <option value={"99"} >その他</option>
            </select>
          </div>
          <div className="m-2">
            <label className="block" htmlFor="nokist">発注No.</label>
            <OkyTextbox id="nokied" wsize="xl" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />
          </div>
          <div className="m-2">
            <label className="block" htmlFor="nokist">客先注文No.</label>
            <OkyTextbox id="nokied" wsize="xl" value={sch_nokied} onChange={(event) => setSch_nokied(event.target.value)} />
          </div>
        </div>
        <div className="bg-white border-gray-200 w-full flex">
          <div className="m-2 w-32">備考</div>
          <div className="m-2 w-full">
            <textarea className="m-2 w-full border-2 border-gray-400 rounded"></textarea>
          </div>
        </div>
      </div>
    </>
    ;

  const InputTableElement =
    <TableBuilder
      table={keiyakuhTable}
      btnflg={true}
      onfunc={undefined}
    />
    ;

  const ButtonAreaElement =
    <>
      <div className="flex justify-between">
        <div>
          <OkyButton color="gray" wsize="md" hsize="lg" disabled={false} onClick={(event) => alert("取消ボタン押下")}>取消</OkyButton>
          <OkyButton color="gray" wsize="md" hsize="lg" disabled={false} onClick={(event) => alert("打切ボタン押下")}>打切</OkyButton>
          <OkyButton color="gray" wsize="md" hsize="lg" disabled={false} onClick={(event) => alert("復活ボタン押下")}>復活</OkyButton>
        </div>
        <div>
          <OkyButton color="gray" wsize="md" hsize="lg" disabled={false} onClick={(event) => alert("行追加ボタン押下")}>明細行追加</OkyButton>
        </div>
      </div>
    </>
    ;

  return (
    <CreateScreenBuilder
      screenTitle={headLabelData.screenTitle}
      screenDetail={headLabelData.screenDetail}
      inputArea={InputAreaElement}
      inputTableArea={InputTableElement}
      buttonArea={ButtonAreaElement}
    />
  );
};

export default Screen;