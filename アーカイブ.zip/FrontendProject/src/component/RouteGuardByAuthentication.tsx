import React, { ReactNode } from "react";
import { useAuthenticateUserContext } from "@/hooks/useAuthorization";
import { Navigate, useLocation } from "react-router-dom";

type Props = {
  component: ReactNode,
  redirect: string,
};

export const RouteGuardByAuthentication: React.FC<Props> = ({component, redirect}) => {
  const user = useAuthenticateUserContext().user;

  if (user) {
    return <>{component}</>
  } else {
    return <Navigate to={redirect} state={{from:useLocation()}} replace={false} />
  }
};