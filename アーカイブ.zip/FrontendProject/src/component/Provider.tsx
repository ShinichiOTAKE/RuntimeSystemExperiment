import React, { ReactNode } from "react";
import { AuthenticationUserProvider, ModalDialogProvider } from "@/provider";

type Props= {
  children: ReactNode,
};

export const Provider: React.FC<Props> = ({children}) => {
  return (
    <>
      <AuthenticationUserProvider>
        <ModalDialogProvider>
          {children}
        </ModalDialogProvider>
      </AuthenticationUserProvider>
    </>
  );
};