import React from "react";

type Props = {
  screenTitle: String,
  screenDetail: String,
  inputArea: React.ReactNode,
  inputTableArea: React.ReactNode,
  buttonArea: React.ReactNode,
}

const CreateScreenBuilder =
  (props: Props) => {
    const {
      screenTitle,
      screenDetail,
      inputArea,
      inputTableArea,
      buttonArea,
    } = props; 

  return (
    <>
      <div className = "header-area mt-2 p-3 bg-okylightgray flex justify-between">
        <div>
          <h1 className="text-3xl">{ screenTitle }</h1>
          <span >{ screenDetail }</span>
        </div>
      </div>
      <div className = "search-area mt-2 p-3 bg-okylightgray">
        { inputArea }
      </div>
      <div className = "result-area mt-2 p-3 bg-okylightgray">
        <div className = " w-full">
          { inputTableArea }
        </div>
      </div>
      <div className = "result-area mt-2 p-3 bg-okylightgray">
        <div className = " w-full">
          { buttonArea }
        </div>
      </div>
    </>
  );
};

export default CreateScreenBuilder;