import React from "react";
import BaseDialog from "@/layout/BaseDialog";

type Props = {
  screenTitle: String,
  screenDetail: String,
  searchArea: React.ReactNode,
  resultTable: React.ReactNode,
  buttonArea: React.ReactNode,
  onClose: () => void;
};

const SelectionDialogBuilder: React.FC<Props> = ({screenTitle,screenDetail,searchArea,resultTable,buttonArea, onClose }) => {
  return (
    <BaseDialog>
      <header className="bg-white text-xs flex">
        <p>画面ID：1234567890</p>
        <p>23/3/15 11:14</p>
          <button type="button" onClick={onClose}>×</button>
      </header>
      <main className="bg-okylightgray">
        <header className="mt-5">
          <h1 className="text-3xl">{screenTitle}</h1>
          <p>{screenDetail}</p>
        </header>
        <article>
          <section className="mt-5">
            <div>{searchArea}</div>
          </section>
          <section className="mt-5">
            <div>{resultTable}</div>
          </section>
        </article>
        <footer className="bg-black">
          {buttonArea}
        </footer>
      </main>
    </BaseDialog>
  );
};

export default SelectionDialogBuilder;