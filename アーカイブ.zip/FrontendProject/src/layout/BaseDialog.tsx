import React, { ReactNode, FC } from "react";

type Props = {
  children: ReactNode,
  onClose?: () => void
};

const BaseDialog: FC<Props> = ({children, onClose}) =>
  <>
    <div className="fixed inset-0 flex justify-center items-center">
      <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={onClose}></div>
      <div className= "relative bg-okylightgray p-1 rounded w-3/5">{children}</div>
    </div>
  </>
;

export default BaseDialog;