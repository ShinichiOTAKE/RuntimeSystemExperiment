module.exports = {
  plugins: {
    tailwindcss: {
      config: './src/style/tailwind.config.js'
    },
    autoprefixer: {},
  },
}
